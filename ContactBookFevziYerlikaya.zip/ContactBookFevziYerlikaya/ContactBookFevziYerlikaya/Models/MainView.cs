﻿using ContactBookFevziYerlikaya.DataService;
using ContactBookFevziYerlikaya.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactBookFevziYerlikaya.Models
{
    public class MainView : ObservableObject
    {
        private object _currentView;
        private BookViewModel _bookViews;

        public MainView()
        {
            var dataAccess = new JsonContactDataService();
            BookViewModel = new BookViewModel(dataAccess);
            CurrentView = BookViewModel;
        }

        public object CurrentView
        {
            get { return _currentView; }
            set { OnPropertyChanged(ref _currentView, value); }
        }

        public BookViewModel BookViewModel
        {
            get { return _bookViews; }
            set { OnPropertyChanged(ref _bookViews, value); }
        }
    }
}
