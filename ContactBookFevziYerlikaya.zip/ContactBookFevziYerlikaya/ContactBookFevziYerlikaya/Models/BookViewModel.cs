﻿using ContactBookFevziYerlikaya.DataService;
using ContactBookFevziYerlikaya.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ContactBookFevziYerlikaya.Models
{
    public class BookViewModel : ObservableObject
    {
        private readonly IContactDataService _dataAccess;

        private ContactsViewModel _contactsViewModel;

        private string _searchText;
        public ICommand LoadContactsCommand { get; private set; }

        public ICommand LoadSearchedCommand { get; private set; }

        public BookViewModel(IContactDataService dataAccess)
        {
            this._dataAccess = dataAccess;

            ContactsViewModel = new ContactsViewModel(dataAccess);

            LoadContactsCommand = new RelayCommand(LoadContacts);
            LoadSearchedCommand = new RelayCommand(LoadFilteredContacts);

        }



        private void LoadFilteredContacts()
        {


            if (SearchText != null)
            {
                var searchResult = _dataAccess.GetContacts()
                    .Where(c => c.Name != null && c.Name.ToUpper().StartsWith(SearchText.ToUpper())
                                || c.Surname != null && c.Surname.ToUpper().StartsWith(SearchText.ToUpper())
                                || c.Email != null && c.Email.ToUpper().Contains(SearchText.ToUpper())
                                || c.PhoneNumber != null && c.PhoneNumber.Contains(SearchText)
                                || c.Age.ToString().Equals(SearchText)
                            ||  c.DateOfBirth.ToString().Contains(SearchText)
                    );

                ContactsViewModel.GetContacts(searchResult);

            }
        }

        private void LoadContacts()
        {
            ContactsViewModel.GetContacts(_dataAccess.GetContacts());
        }

        public ContactsViewModel ContactsViewModel
        {
            get { return _contactsViewModel; }
            set { OnPropertyChanged(ref _contactsViewModel, value); }
        }

        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;

                OnPropertyChanged("SearchText");

            }
        }
        private bool IsDateInOneWeek(DateTime date)
        {
            DateTime today = DateTime.Now;
            var weekLater = today.AddDays(7);

            if (date.Month == today.Month)
            {
                if ((weekLater.Day >= date.Day) && (today.Day <= date.Day))
                {
                    return true;
                }
            }

            return false;

        }
    }
}
