﻿
namespace ContactBookFevziYerlikaya.Utility
{
    public interface IEntity
    {
        string Email { get; set; }
    }
}
