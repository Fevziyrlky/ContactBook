﻿using System;
using System.Collections.Generic;
using ContactBookFevziYerlikaya.Utility;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContactBookFevziYerlikaya.DataService
{
    public interface IContactDataService
    {
        IEnumerable<Contact> GetContacts();
        void Save(IEnumerable<Contact> contacts);
       
    }
}
